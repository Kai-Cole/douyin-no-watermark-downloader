@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在检查依赖...
python -c "import playwright" 2>nul
if errorlevel 1 (
  echo 首次运行，正在安装 playwright...
  python -m pip install playwright -i https://pypi.tuna.tsinghua.edu.cn/simple
  if errorlevel 1 (
    echo 安装失败，请确认 python 已加入 PATH
    pause
    exit /b
  )
)
echo.
echo 启动中，浏览器会自动打开 http://127.0.0.1:3000
echo 关闭这个窗口即停止程序。
echo.
python app.py
pause