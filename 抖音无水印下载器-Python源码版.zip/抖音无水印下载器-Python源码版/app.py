#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音无水印下载器 · 本地网站版

启动后会在本机 3000 端口跑一个网页服务：
    http://127.0.0.1:3000        本机打开
    http://<本机局域网IP>:3000   同一 WiFi 下的其他电脑/手机也能用

打包成 exe：
    python -m PyInstaller --onefile --console --name DouyinNoWM --collect-all playwright app.py
"""
import json
import os
import re
import socket
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from urllib.request import Request, urlopen

# ---------------------------------------------------------------- 基础配置
PORT = int(os.environ.get("PORT", "3000"))
APP_NAME = "DouyinNoWM"

if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import dyengine as engine  # 同目录的解析引擎  # noqa: E402
from playwright.sync_api import sync_playwright  # noqa: E402


def _profile_dir():
    env = os.environ.get("DOUYIN_PROFILE")
    if env:
        return env
    local = os.path.join(BASE_DIR, "browser-profile")
    if os.path.isdir(local) and os.listdir(local):
        return local
    la = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(la, APP_NAME, "browser-profile")


PROFILE_DIR = _profile_dir()
try:
    os.makedirs(PROFILE_DIR, exist_ok=True)
except Exception:
    pass
engine.USER_DIR = PROFILE_DIR

BROWSER_LOCK = threading.Lock()
_login_cache = {"ts": 0, "ok": False}


# ---------------------------------------------------------------- 解析核心
def parse_link(text):
    link = engine.extract_link(text)
    if not link:
        return {"ok": False, "code": "BAD_INPUT", "msg": "没找到抖音链接，请粘贴完整的分享文案"}

    with BROWSER_LOCK:
        ctx = None
        try:
            with sync_playwright() as p:
                ctx = engine.launch(p, headless=True)
                ctx.add_init_script(engine.HOOK_JS)
                page = ctx.pages[0] if ctx.pages else ctx.new_page()

                media = []

                def on_req(r):
                    u = r.url
                    if re.search(r"douyinvod|v\d+-web|bytegecko|amemv|video/tos", u) and not re.search(
                        r"effect|douyinstatic|byteeffecttos|static|\.jpe?g|\.webp|\.png", u
                    ):
                        media.append(u)

                page.on("request", on_req)
                try:
                    page.goto(link, wait_until="domcontentloaded", timeout=45000)
                except Exception:
                    try:
                        page.goto(link, wait_until="load", timeout=30000)
                    except Exception as e:
                        return {"ok": False, "code": "FAIL", "msg": "打开链接失败：%s" % e}

                got = None
                for _ in range(26):
                    page.wait_for_timeout(500)
                    caps = page.evaluate("() => (window.__DY_CAP || [])")
                    if caps:
                        got = caps[0]
                        break
                page.wait_for_timeout(1200)
                if not got:
                    caps = page.evaluate("() => (window.__DY_CAP || [])")
                    if caps:
                        got = caps[0]

                need_login = False
                try:
                    if not engine.logged_in(ctx):
                        need_login = True
                except Exception:
                    pass

                if got:
                    try:
                        j = json.loads(got)
                        d = j.get("aweme_detail") or j.get("aweme") or j
                        if isinstance(d, dict) and (d.get("video") or d.get("images")):
                            data = engine.pick_from_detail(d)
                            if data.get("video_url") or data.get("images"):
                                if not data.get("video_url") and media:
                                    data["video_url"] = media[-1]
                                    data["video_urls"] = [media[-1]]
                                return {"ok": True, "data": data}
                    except Exception:
                        pass

                if media:
                    uniq = []
                    for u in media:
                        if u not in uniq:
                            uniq.append(u)
                    if uniq:
                        return {
                            "ok": True,
                            "data": {
                                "type": "video",
                                "title": "",
                                "author": "",
                                "avatar": "",
                                "cover": "",
                                "video_url": uniq[-1],
                                "video_urls": uniq[::-1],
                                "images": [],
                                "aweme_id": engine.get_id(link),
                            },
                        }

                if need_login:
                    return {
                        "ok": False,
                        "code": "NEED_LOGIN",
                        "msg": "抖音要求登录。点页面上的「登录抖音」按钮，扫码登录一次即可（之后长期有效）",
                    }
                return {"ok": False, "code": "FAIL", "msg": "没抓到作品数据，作品可能已删除或为私密作品"}
        finally:
            try:
                if ctx:
                    ctx.close()
            except Exception:
                pass


def do_login():
    """弹出一个可见浏览器窗口，让用户扫码，登录成功后自动关闭"""
    with BROWSER_LOCK:
        ctx = None
        try:
            with sync_playwright() as p:
                ctx = engine.launch(p, headless=False)
                page = ctx.pages[0] if ctx.pages else ctx.new_page()
                try:
                    page.goto("https://www.douyin.com/", wait_until="domcontentloaded", timeout=45000)
                except Exception:
                    pass
                ok = False
                t0 = time.time()
                while time.time() - t0 < 300:
                    time.sleep(2)
                    try:
                        if engine.logged_in(ctx):
                            ok = True
                            break
                    except Exception:
                        break
                if ok:
                    time.sleep(2)
                    try:
                        ok = engine.logged_in(ctx)
                    except Exception:
                        pass
                _login_cache["ts"] = time.time()
                _login_cache["ok"] = ok
                return ok
        except Exception:
            return False
        finally:
            try:
                if ctx:
                    ctx.close()
            except Exception:
                pass


def check_login(force=False):
    now = time.time()
    if not force and now - _login_cache["ts"] < 30:
        return _login_cache["ok"]
    with BROWSER_LOCK:
        ctx = None
        try:
            with sync_playwright() as p:
                ctx = engine.launch(p, headless=True)
                ok = engine.logged_in(ctx)
        except Exception:
            ok = False
        finally:
            try:
                if ctx:
                    ctx.close()
            except Exception:
                pass
    _login_cache["ts"] = now
    _login_cache["ok"] = ok
    return ok


# ---------------------------------------------------------------- 转发下载
MEDIA_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    ),
    "Referer": "https://www.douyin.com/",
}


def stream_media(handler, target, as_attachment=False, filename="video.mp4"):
    req = Request(target, headers=MEDIA_HEADERS)
    rng = handler.headers.get("Range")
    if rng:
        req.add_header("Range", rng)
    try:
        r = urlopen(req, timeout=30)
    except Exception as e:
        handler.send_json(502, {"code": 1, "msg": "源地址不可用：%s" % e})
        return

    handler.send_response(getattr(r, "status", 200))
    ctype = r.headers.get("Content-Type") or "application/octet-stream"
    handler.send_header("Content-Type", ctype)
    length = r.headers.get("Content-Length")
    if length:
        handler.send_header("Content-Length", length)
    handler.send_header("Accept-Ranges", "bytes")
    handler.send_header("Access-Control-Allow-Origin", "*")
    if as_attachment:
        handler.send_header(
            "Content-Disposition", 'attachment; filename="%s"' % filename.encode("utf-8").decode("latin-1")
        )
    handler.end_headers()
    try:
        while True:
            chunk = r.read(262144)
            if not chunk:
                break
            handler.wfile.write(chunk)
    except Exception:
        pass
    finally:
        try:
            r.close()
        except Exception:
            pass


def safe_filename(data):
    name = re.sub(r'[\\/:*?"<>|\s]+', "_", (data.get("title") or "douyin_video")).strip("_")
    name = name[:60] or "douyin_video"
    if data.get("type") == "image":
        return name + ".jpg"
    return name + ".mp4"


# ---------------------------------------------------------------- 页面
HTML = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>抖音无水印下载器</title>
<style>
:root{
  --bg:#0e1014;--card:#171a21;--card2:#1e222b;--line:#2a2f3a;
  --txt:#e9ecf2;--sub:#8b92a3;--accent:#2f6bff;--ok:#2ecc71;--warn:#ff9d5c;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);
  font-family:-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  -webkit-font-smoothing:antialiased}
.wrap{max-width:820px;margin:0 auto;padding:28px 20px 80px}
header{display:flex;align-items:center;gap:12px;margin-bottom:22px}
.logo{width:40px;height:40px;border-radius:11px;background:linear-gradient(135deg,#2f6bff,#00c6ff);
  display:flex;align-items:center;justify-content:center;font-weight:700;font-size:19px;color:#fff}
h1{font-size:20px;margin:0;font-weight:650;letter-spacing:.3px}
.tagline{font-size:12.5px;color:var(--sub);margin-top:3px}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px}
textarea{width:100%;height:104px;background:var(--card2);border:1px solid var(--line);
  border-radius:12px;color:var(--txt);padding:12px;font-size:14px;line-height:1.6;
  resize:vertical;outline:none;font-family:inherit}
textarea:focus{border-color:#3d4a66}
.rows{display:flex;gap:10px;margin-top:12px;flex-wrap:wrap}
button{border:0;border-radius:11px;padding:11px 20px;font-size:14px;cursor:pointer;
  font-family:inherit;transition:.16s;font-weight:500}
button:disabled{opacity:.5;cursor:not-allowed}
.primary{background:var(--accent);color:#fff}
.primary:hover:not(:disabled){background:#3f7aff}
.ghost{background:transparent;border:1px solid var(--line);color:var(--sub)}
.ghost:hover{border-color:#3d4a66;color:var(--txt)}
.mini{font-size:13px;padding:8px 14px;border-radius:9px}
.hint{font-size:12.5px;color:var(--sub);margin-top:12px;line-height:1.7}
.status{margin-top:14px;font-size:13.5px;line-height:1.7}
.status.err{color:#ff7b72}
.status.ok{color:var(--ok)}
.spin{display:inline-block;width:13px;height:13px;border:2px solid #3a4152;border-top-color:var(--accent);
  border-radius:50%;animation:sp .7s linear infinite;vertical-align:-2px;margin-right:7px}
@keyframes sp{to{transform:rotate(360deg)}}
.banner{background:rgba(255,157,92,.09);border:1px solid rgba(255,157,92,.3);color:var(--warn);
  border-radius:12px;padding:12px 14px;font-size:13.5px;margin-bottom:16px;display:none;
  align-items:center;gap:12px;justify-content:space-between;flex-wrap:wrap}
.result{margin-top:22px;display:none}
.rhead{display:flex;align-items:center;gap:12px;margin-bottom:14px}
.avatar{width:42px;height:42px;border-radius:50%;background:var(--card2);object-fit:cover}
.who{font-size:14px;font-weight:600;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.badge{font-size:12px;padding:4px 11px;border-radius:999px;background:rgba(47,107,255,.14);color:#8fb0ff}
.cover{display:block;width:100%;max-height:420px;object-fit:contain;border-radius:13px;background:#0b0d11}
.desc{font-size:13.5px;color:#b6bdcc;line-height:1.7;margin-top:14px}
.acts{display:flex;gap:10px;margin-top:18px;flex-wrap:wrap}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:10px;margin-top:14px}
.grid img{width:100%;height:120px;object-fit:cover;border-radius:10px;background:#0b0d11;cursor:pointer}
.foot{margin-top:34px;font-size:12px;color:#5d6474;line-height:1.9;
  border-top:1px solid var(--line);padding-top:16px}
.hist{margin-top:22px}
.hist h3{font-size:13px;color:var(--sub);font-weight:500;margin:0 0 10px}
.hitem{display:flex;gap:10px;align-items:center;padding:9px 12px;border-radius:10px;
  background:var(--card);border:1px solid var(--line);margin-bottom:8px;cursor:pointer}
.hitem:hover{border-color:#3d4a66}
.hitem img{width:44px;height:44px;border-radius:7px;object-fit:cover;background:var(--card2)}
.hitem .t{font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hitem .s{font-size:11.5px;color:var(--sub);margin-top:3px}
@media(max-width:520px){.wrap{padding:18px 14px 60px}h1{font-size:18px}.rows button{flex:1}}
</style>
</head>
<body>
<div class="wrap">
  <header>
    <div class="logo">抖</div>
    <div>
      <h1>抖音无水印下载器</h1>
      <div class="tagline">粘贴分享链接 → 解析 → 直接下载。无广告，纯本地运行</div>
    </div>
  </header>

  <div class="banner" id="banner">
    <span id="bannerTxt">还没登录抖音，需要登录一次才能解析</span>
    <button class="primary mini" onclick="doLogin()" id="loginBtn">登录抖音</button>
  </div>

  <div class="card">
    <textarea id="inp" placeholder="在这里粘贴抖音分享的链接或整段文案，例如：
7.94 复制打开抖音，看看【某某的作品】… https://v.douyin.com/xxxxxx/ …"></textarea>
    <div class="rows">
      <button class="primary" id="goBtn" onclick="go()">开始解析</button>
      <button class="ghost" onclick="paste()">粘贴剪贴板</button>
      <button class="ghost" onclick="clearAll()">清空</button>
    </div>
    <div class="status" id="status"></div>
  </div>

  <div class="result" id="result"></div>

  <div class="hist" id="hist"></div>

  <div class="foot">
    仅用于个人收藏与离线观看。去掉水印后二次发布、搬运、商用属于侵犯著作权，转发或二创请先获得原作者授权。<br>
    解析依赖你本机已登录的抖音会话：登录状态过期后点「登录抖音」重新扫码即可。
  </div>
</div>

<script>
let last = null;
const $ = id => document.getElementById(id);

function setStatus(html, cls){
  const s = $('status');
  s.className = 'status ' + (cls || '');
  s.innerHTML = html;
}

async function health(){
  try{
    const r = await fetch('/api/health');
    const j = await r.json();
    if(!j.login){
      $('banner').style.display = 'flex';
    }else{
      $('banner').style.display = 'none';
    }
  }catch(e){}
}

async function doLogin(){
  const b = $('loginBtn');
  b.disabled = true;
  b.textContent = '等待扫码…';
  $('bannerTxt').textContent = '浏览器窗口已打开，请用抖音 App 扫码，登录成功后窗口自动关闭';
  try{
    const r = await fetch('/api/login', {method:'POST'});
    const j = await r.json();
    if(j.ok){
      $('banner').style.display = 'none';
      $('bannerTxt').textContent = '';
      setStatus('登录成功，可以开始解析了', 'ok');
    }else{
      $('bannerTxt').textContent = '没检测到登录，请重试；窗口若已关闭可再点一次';
    }
  }catch(e){
    $('bannerTxt').textContent = '登录请求失败：' + e.message;
  }
  b.disabled = false;
  b.textContent = '登录抖音';
}

async function paste(){
  try{
    const t = await navigator.clipboard.readText();
    if(t){ $('inp').value = t; }
    else{ setStatus('剪贴板是空的', 'err'); }
  }catch(e){
    setStatus('浏览器不让读剪贴板，请手动 Ctrl+V 粘贴', 'err');
  }
}

function clearAll(){
  $('inp').value = '';
  $('result').style.display = 'none';
  setStatus('');
}

async function go(){
  const text = $('inp').value.trim();
  if(!text){ setStatus('先粘贴链接', 'err'); return; }
  const btn = $('goBtn');
  btn.disabled = true;
  const t0 = Date.now();
  const timer = setInterval(()=>{
    setStatus('<span class="spin"></span>正在用本地浏览器引擎解析… ' + Math.round((Date.now()-t0)/1000) + 's');
  }, 500);
  setStatus('<span class="spin"></span>正在解析…');

  try{
    const r = await fetch('/api/parse', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({text})
    });
    const j = await r.json();
    clearInterval(timer);

    if(!j.ok){
      if(j.code === 'NEED_LOGIN'){
        $('banner').style.display = 'flex';
        $('bannerTxt').textContent = '需要登录抖音后才能解析';
      }
      setStatus(j.msg || '解析失败', 'err');
      btn.disabled = false;
      return;
    }

    last = j.data;
    render(j.data);
    setStatus('解析成功（用时 ' + Math.round((Date.now()-t0)/1000) + ' 秒）', 'ok');
    saveHist(j.data);
  }catch(e){
    clearInterval(timer);
    setStatus('请求失败：' + e.message, 'err');
  }
  btn.disabled = false;
}

function proxy(u){ return '/api/proxy?url=' + encodeURIComponent(u); }

function render(d){
  const box = $('result');
  let h = '';
  h += '<div class="card">';
  h += '<div class="rhead">';
  if(d.avatar) h += '<img class="avatar" src="' + d.avatar + '">';
  h += '<div class="who">' + (d.author || '未知作者') + '</div>';
  h += '<div class="badge">' + (d.type === 'video' ? '视频' : '图文 ' + (d.images||[]).length + ' 张') + '</div>';
  h += '</div>';

  if(d.type === 'video'){
    if(d.cover) h += '<img class="cover" src="' + d.cover + '">';
    h += '<video class="cover" style="margin-top:12px" controls preload="metadata" src="' + proxy(d.video_url) + '"></video>';
  }else{
    h += '<div class="grid">';
    (d.images||[]).forEach(u => { h += '<img src="' + proxy(u) + '" onclick="window.open(\'' + proxy(u) + '\')">'; });
    h += '</div>';
  }

  if(d.title) h += '<div class="desc">' + d.title + '</div>';

  h += '<div class="acts">';
  if(d.type === 'video'){
    h += '<button class="primary" onclick="dl()">下载视频到电脑</button>';
    h += '<button class="ghost" onclick="copyLink()">复制直链</button>';
  }else{
    h += '<button class="primary" onclick="dlImages()">逐张下载图片</button>';
  }
  h += '</div></div>';

  box.innerHTML = h;
  box.style.display = 'block';
}

function dl(){
  if(!last || !last.video_url) return;
  location.href = '/api/download?url=' + encodeURIComponent(last.video_url);
}

function dlImages(){
  if(!last || !last.images) return;
  last.images.forEach((u, i) => {
    setTimeout(()=>{ location.href = '/api/download?url=' + encodeURIComponent(u) + '&idx=' + i; }, i * 400);
  });
}

function copyLink(){
  if(!last) return;
  const u = last.type === 'video' ? last.video_url : (last.images||[])[0];
  navigator.clipboard.writeText(u).then(
    ()=> setStatus('直链已复制，可贴到下载工具里用', 'ok'),
    ()=> setStatus('复制失败，右键上面的视频可另存', 'err')
  );
}

function saveHist(d){
  try{
    let a = JSON.parse(localStorage.getItem('dyhist') || '[]');
    a = a.filter(x => x.aweme_id !== d.aweme_id);
    a.unshift({aweme_id:d.aweme_id, title:d.title, author:d.author, cover:d.cover, type:d.type, t:Date.now()});
    a = a.slice(0, 8);
    localStorage.setItem('dyhist', JSON.stringify(a));
    renderHist();
  }catch(e){}
}

function renderHist(){
  let a = [];
  try{ a = JSON.parse(localStorage.getItem('dyhist') || '[]'); }catch(e){}
  if(!a.length){ $('hist').innerHTML = ''; return; }
  let h = '<h3>最近解析</h3>';
  a.forEach(x=>{
    h += '<div class="hitem" onclick="reParse(\'' + x.aweme_id + '\')">';
    if(x.cover) h += '<img src="' + x.cover + '">';
    h += '<div style="flex:1;min-width:0"><div class="t">' + (x.title || '(无标题)') + '</div>';
    h += '<div class="s">' + (x.author || '') + ' · ' + (x.type === 'video' ? '视频' : '图文') + '</div></div></div>';
  });
  $('hist').innerHTML = h;
}

function reParse(id){
  $('inp').value = 'https://www.douyin.com/video/' + id;
  go();
}

renderHist();
health();
</script>
</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):
    server_version = "DouyinNoWM"

    def log_message(self, fmt, *args):
        pass

    def send_json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.end_headers()

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)

        if u.path in ("/", "/index.html"):
            body = HTML.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if u.path == "/api/health":
            ok = check_login()
            return self.send_json(200, {"code": 0, "login": ok, "engine": engine.EXE or "chromium"})

        if u.path == "/api/proxy":
            target = (q.get("url") or [""])[0]
            if not target:
                return self.send_json(400, {"code": 1, "msg": "缺少 url"})
            return stream_media(self, target)

        if u.path == "/api/download":
            target = (q.get("url") or [""])[0]
            if not target:
                return self.send_json(400, {"code": 1, "msg": "缺少 url"})
            idx = (q.get("idx") or [""])[0]
            name = ("image_%s.jpg" % (idx or "0")) if idx else "douyin_video_%s.mp4" % int(time.time())
            return stream_media(self, target, as_attachment=True, filename=name)

        return self.send_json(404, {"code": 1, "msg": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        if u.path == "/api/login":
            ok = do_login()
            return self.send_json(200, {"ok": ok})

        if u.path == "/api/parse":
            try:
                length = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(length).decode("utf-8", "replace") if length else ""
                try:
                    data = json.loads(raw) if raw else {}
                except Exception:
                    data = {}
                text = data.get("text") or raw
            except Exception:
                text = ""
            if not text:
                q = parse_qs(u.query)
                text = (q.get("text") or q.get("url") or [""])[0]
            try:
                res = parse_link(text)
            except Exception as e:
                res = {"ok": False, "code": "FAIL", "msg": "解析异常：%s" % e}
            return self.send_json(200, res)

        return self.send_json(404, {"code": 1, "msg": "not found"})


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def main():
    ip = lan_ip()
    print("")
    print("  ===============================================")
    print("   抖音无水印下载器 已启动")
    print("   本机打开：   http://127.0.0.1:%d" % PORT)
    print("   其他设备：   http://%s:%d  （同一 WiFi / 局域网）" % (ip, PORT))
    print("   登录状态：   %s" % ("已登录" if check_login(True) else "未登录（页面里点“登录抖音”）"))
    print("   关闭这个黑窗口即可停止程序")
    print("  ===============================================")
    print("")

    try:
        srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    except OSError:
        print("")
        print("  端口 %d 已被占用 —— 程序可能已经在运行了。" % PORT)
        print("  已为你打开 http://127.0.0.1:%d" % PORT)
        print("")
        webbrowser.open("http://127.0.0.1:%d" % PORT)
        time.sleep(4)
        return
    srv.daemon_threads = True
    threading.Thread(
        target=lambda: (time.sleep(1.2), webbrowser.open("http://127.0.0.1:%d" % PORT)),
        daemon=True,
    ).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
