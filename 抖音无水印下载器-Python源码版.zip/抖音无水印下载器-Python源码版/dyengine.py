#!/usr/bin/env python3
"""
抖音无水印解析引擎（浏览器内核版）

为什么需要浏览器？
    2026 年抖音已对纯 HTTP 请求下发 JS 反爬挑战 + 登录/滑块墙，
    分享页的 _ROUTER_DATA 也不再有 videoInfoRes。
    所以只能让一个真实浏览器内核带着「你自己的登录态」去拿数据。

用法：
    python3 engine.py --login            首次使用：弹出浏览器，手动登录抖音，登录态会保存
    python3 engine.py --resolve "<链接或分享文案>"   解析，输出 JSON 到 stdout
    python3 engine.py --check            检查登录态是否有效

输出的 JSON 结构：
    {"ok": true, "data": {type, title, author, cover, video_url, video_urls, images, aweme_id}}
    {"ok": false, "code": "NEED_LOGIN"|"FAIL", "msg": "..."}
"""

import argparse
import json
import os
import re
import sys
import time

os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "")

# 保证中文 JSON 在管道里也是 UTF-8，避免 Windows 下 cp936 乱码
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

USER_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "browser-profile")


def _find_browser():
    """优先用 CHROME_PATH，其次自动找系统里的 Chrome / Edge（免下载）"""
    env = os.environ.get("CHROME_PATH", "")
    if env and os.path.exists(env):
        return env
    la = os.environ.get("LOCALAPPDATA", "")
    if os.name == "nt":
        cands = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.join(la, r"Google\Chrome\Application\chrome.exe") if la else "",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        ]
    else:
        cands = ["/usr/local/bin/chromium", "/usr/bin/chromium", "/usr/bin/google-chrome"]
    for p in cands:
        if p and os.path.exists(p):
            return p
    return ""


EXE = _find_browser()

UA_PC = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)

ARGS = [
    "--no-sandbox",
    "--disable-blink-features=AutomationControlled",
    "--disable-dev-shm-usage",
]

# 在页面里挂钩子，把「作品详情」接口的原始 JSON 抓下来
HOOK_JS = r"""
(function () {
  if (window.__DY_CAP) return;
  window.__DY_CAP = [];
  const want = /\/(aweme|aweme)\/v?1?\/?web\/aweme\/detail|aweme\/detail/;
  const keep = (u, t) => {
    try {
      if (!u) return;
      if (String(u).indexOf('aweme/detail') > -1 && t && t.length > 200) {
        window.__DY_CAP.push(t);
      }
    } catch (e) {}
  };
  const of = window.fetch;
  window.fetch = async function (...a) {
    const r = await of.apply(this, a);
    try {
      const u = typeof a[0] === 'string' ? a[0] : (a[0] && a[0].url) || '';
      const t = await r.clone().text();
      keep(u, t);
    } catch (e) {}
    return r;
  };
  const ox = XMLHttpRequest.prototype.open;
  const os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) {
    this.__u = u;
    return ox.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    this.addEventListener('load', function () {
      try { keep(this.__u, this.responseText); } catch (e) {}
    });
    return os.apply(this, arguments);
  };
})();
"""


def out(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False))
    sys.stdout.flush()
    sys.exit(code)


def extract_link(text):
    urls = re.findall(r"https?://[^\s\"'<>，。、）】]+", text or "")
    for u in urls:
        if "douyin.com" in u:
            return u
    return urls[0] if urls else ""


def get_id(u):
    for pat in (
        r"(?:video|note|slides|share/video|share/note)/(\d{15,25})",
        r"modal_id=(\d{15,25})",
        r"aweme_id=(\d{15,25})",
        r"(\d{19})",
    ):
        m = re.search(pat, u or "")
        if m:
            return m.group(1)
    return ""


def launch(p, headless=True):
    from playwright.sync_api import sync_playwright  # noqa
    kw = dict(
        user_data_dir=USER_DIR,
        headless=headless,
        args=ARGS,
        user_agent=UA_PC,
        locale="zh-CN",
        viewport={"width": 1440, "height": 900},
        extra_http_headers={"Accept-Language": "zh-CN,zh;q=0.9"},
    )
    if os.path.exists(EXE):
        kw["executable_path"] = EXE
    return p.chromium.launch_persistent_context(**kw)


def logged_in(ctx):
    names = {c["name"] for c in ctx.cookies()}
    # passport_csrf_token 匿名访客也会有，不能用来判断登录
    return any(n in names for n in ("sessionid", "sessionid_ss", "sid_tt", "uid_tt"))


# ============================ 登录模式 ============================
def do_login():
    from playwright.sync_api import sync_playwright

    wait_s = int(os.environ.get("LOGIN_WAIT", "600"))
    with sync_playwright() as p:
        ctx = launch(p, headless=False)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        try:
            page.goto("https://www.douyin.com/", wait_until="domcontentloaded", timeout=45000)
        except Exception as e:
            print("open douyin failed: %s" % e)
        print("[LOGIN] browser opened (using %s)" % (EXE or "playwright chromium"))
        print("[LOGIN] please scan the QR code with Douyin App in the browser window")
        print("[LOGIN] this window closes by itself once login is detected")
        ok = False
        t0 = time.time()
        while time.time() - t0 < wait_s:
            time.sleep(3)
            try:
                if logged_in(ctx):
                    ok = True
                    break
            except Exception:
                break
            if int(time.time() - t0) % 15 < 3:
                print("[LOGIN] waiting... %ds" % int(time.time() - t0))
        if ok:
            time.sleep(2)
            try:
                if not logged_in(ctx):  # 二次确认
                    ok = False
            except Exception:
                pass
        try:
            ctx.close()
        except Exception:
            pass
        print("[LOGIN] result: %s" % ("OK" if ok else "NO_SESSION"))
        out({"ok": ok, "msg": "login done" if ok else "no session found"}, 0 if ok else 2)


# ============================ 检查模式 ============================
def do_check():
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        ctx = launch(p, headless=True)
        ok = logged_in(ctx)
        ctx.close()
        out({"ok": ok, "msg": "登录态有效" if ok else "未登录，请先运行 python3 engine.py --login"}, 0 if ok else 2)


# ============================ 解析模式 ============================
def pick_from_detail(d):
    """从 aweme_detail JSON 里抽无水印地址"""
    video = d.get("video") or {}
    play = video.get("play_addr") or {}
    urls = []
    # web 端返回的 url_list 本身就是无水印流（不带 playwm）
    for u in play.get("url_list") or []:
        u2 = u.replace("/playwm/", "/play/").replace("playwm", "play")
        if u2 not in urls:
            urls.append(u2)
    uri = play.get("uri") or ""
    if uri:
        urls.append(
            "https://aweme.snssdk.com/aweme/v1/play/?video_id=%s&ratio=1080p&line=0" % uri
        )
    images = []
    for img in d.get("images") or []:
        lst = img.get("url_list") or []
        if lst:
            images.append(lst[-1] if len(lst) > 1 else lst[0])
    author = (d.get("author") or {}).get("nickname") or ""
    avatar = (
        ((d.get("author") or {}).get("avatar_thumb") or {}).get("url_list") or [""]
    )[0]
    cover = (
        ((video.get("cover") or {}).get("url_list") or [""])[0]
        or ((video.get("origin_cover") or {}).get("url_list") or [""])[0]
    )
    return {
        "aweme_id": d.get("aweme_id") or "",
        "type": "image" if images else "video",
        "title": d.get("desc") or "",
        "author": author,
        "avatar": avatar,
        "cover": cover,
        "video_url": urls[0] if urls else "",
        "video_urls": urls,
        "images": images,
    }


def do_resolve(text):
    from playwright.sync_api import sync_playwright

    link = extract_link(text)
    if not link:
        out({"ok": False, "code": "FAIL", "msg": "没找到链接，请粘贴完整分享文案"}, 1)

    with sync_playwright() as p:
        ctx = launch(p, headless=True)
        ctx.add_init_script(HOOK_JS)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()

        media_urls = []

        def on_req(r):
            u = r.url
            # 只认真正的视频 CDN，排除贴纸/特效素材、静态资源、封面图
            if re.search(r"douyinvod|v\d+-web|bytegecko|amemv|video/tos", u) and not re.search(
                r"effect|douyinstatic|byteeffecttos|static|\.jpe?g|\.webp|\.png", u
            ):
                media_urls.append(u)

        page.on("request", on_req)

        try:
            page.goto(link, wait_until="domcontentloaded", timeout=45000)
        except Exception:
            try:
                page.goto(link, wait_until="load", timeout=30000)
            except Exception as e:
                ctx.close()
                out({"ok": False, "code": "FAIL", "msg": "打开链接失败: %s" % e}, 1)

        # 等详情接口或者页面把数据吐出来
        got = None
        for _ in range(24):  # 最多约 12 秒
            page.wait_for_timeout(500)
            caps = page.evaluate("() => (window.__DY_CAP || [])")
            if caps:
                got = caps[0]
                break
        page.wait_for_timeout(1500)
        caps = page.evaluate("() => (window.__DY_CAP || [])")
        if caps and not got:
            got = caps[0]

        need_login = False
        try:
            body_txt = page.inner_text("body")[:400]
        except Exception:
            body_txt = ""
        if ("登录" in body_txt and "验证" in body_txt) or "请完成下列验证" in body_txt:
            need_login = True
        if not logged_in(ctx):
            need_login = True

        if got:
            try:
                j = json.loads(got)
                d = j.get("aweme_detail") or j.get("aweme") or j
                if isinstance(d, dict) and (d.get("video") or d.get("images")):
                    data = pick_from_detail(d)
                    if data["video_url"] or data["images"]:
                        if not data["video_url"] and media_urls:
                            data["video_url"] = media_urls[-1]
                        ctx.close()
                        out({"ok": True, "data": data}, 0)
            except Exception:
                pass

        # 兜底：直接抓播放中的 CDN 流
        if media_urls:
            uniq = []
            for u in media_urls:
                if u not in uniq:
                    uniq.append(u)
            ctx.close()
            out(
                {
                    "ok": True,
                    "data": {
                        "type": "video",
                        "title": "",
                        "author": "",
                        "avatar": "",
                        "cover": "",
                        "video_url": uniq[-1],
                        "video_urls": uniq[::-1],
                        "images": [],
                        "aweme_id": get_id(link),
                    },
                },
                0,
            )

        ctx.close()
        if need_login:
            out(
                {
                    "ok": False,
                    "code": "NEED_LOGIN",
                    "msg": "抖音要求登录/验证。请先在服务器上运行 python3 engine.py --login 登录一次抖音账号",
                },
                2,
            )
        out({"ok": False, "code": "FAIL", "msg": "没抓到作品数据，作品可能已删除或为私密作品"}, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--login", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--resolve", default="")
    a = ap.parse_args()
    if a.login:
        do_login()
    elif a.check:
        do_check()
    elif a.resolve:
        do_resolve(a.resolve)
    else:
        ap.print_help()


if __name__ == "__main__":
    main()
