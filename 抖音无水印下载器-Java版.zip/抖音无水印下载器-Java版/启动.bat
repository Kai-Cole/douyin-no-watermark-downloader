@echo off
chcp 65001 >nul
title Douyin NoWM (Java)
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo [!] Java not found. Install JDK/JRE 8+ first, then add it to PATH.
  pause
  exit /b
)
echo ==============================================
echo   Douyin NoWM Downloader (Java edition)
echo   Opening http://127.0.0.1:3000 ...
echo   Close this window to stop.
echo ==============================================
java -Dnowm.home="%~dp0" -jar DouyinNoWM.jar
pause