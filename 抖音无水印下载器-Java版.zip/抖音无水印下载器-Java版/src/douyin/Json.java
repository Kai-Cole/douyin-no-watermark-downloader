package douyin;

import java.util.List;
import java.util.Map;

/** 一个极简 JSON 输出 / 极简 JSON 取值工具，JDK 8 自带能力，零第三方依赖 */
public final class Json {

    private Json() {
    }

    public static String dump(Object o) {
        StringBuilder sb = new StringBuilder();
        write(sb, o);
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private static void write(StringBuilder sb, Object o) {
        if (o == null) {
            sb.append("null");
        } else if (o instanceof String) {
            sb.append(quote((String) o));
        } else if (o instanceof Boolean || o instanceof Number) {
            sb.append(o.toString());
        } else if (o instanceof Map) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) {
                if (!first) {
                    sb.append(',');
                }
                first = false;
                sb.append(quote(String.valueOf(e.getKey()))).append(':');
                write(sb, e.getValue());
            }
            sb.append('}');
        } else if (o instanceof List) {
            sb.append('[');
            boolean first = true;
            for (Object v : (List<Object>) o) {
                if (!first) {
                    sb.append(',');
                }
                first = false;
                write(sb, v);
            }
            sb.append(']');
        } else {
            sb.append(quote(o.toString()));
        }
    }

    public static String quote(String s) {
        if (s == null) {
            return "\"\"";
        }
        StringBuilder sb = new StringBuilder(s.length() + 2);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        sb.append('"');
        return sb.toString();
    }

    /** 从 {"text": "..."} 这样的扁平 JSON 里取一个字符串字段 */
    public static String field(String json, String key) {        if (json == null) {
            return null;
        }
        String needle = "\"" + key + "\"";
        int i = json.indexOf(needle);
        if (i < 0) {
            return null;
        }
        int colon = json.indexOf(':', i + needle.length());
        if (colon < 0) {
            return null;
        }
        int q = json.indexOf('"', colon + 1);
        if (q < 0) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        boolean esc = false;
        for (int p = q + 1; p < json.length(); p++) {
            char c = json.charAt(p);
            if (esc) {
                if (c == 'n') {
                    sb.append('\n');
                } else if (c == 'r') {
                    sb.append('\r');
                } else if (c == 't') {
                    sb.append('\t');
                } else if (c == 'u') {
                    String hex = json.substring(p + 1, Math.min(p + 5, json.length()));
                    try {
                        sb.append((char) Integer.parseInt(hex, 16));
                    } catch (RuntimeException e) {
                        // 忽略
                    }
                    p += 4;
                } else {
                    sb.append(c);
                }
                esc = false;
            } else if (c == '\\') {
                esc = true;
            } else if (c == '"') {
                return sb.toString();
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
