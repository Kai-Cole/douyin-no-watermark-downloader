package douyin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 极简 JSON 解析器（零依赖，JDK 8）。
 * 只负责把 JSON 文本变成 Map / List / String / Double / Boolean / null，
 * 够解析抖音的 aweme/detail 响应和 CDP 的调试消息。
 */
public final class JsonParse {

    private final String src;
    private int pos;

    private JsonParse(String src) {
        this.src = src;
        this.pos = 0;
    }

    public static Object parse(String text) {
        if (text == null) {
            return null;
        }
        JsonParse p = new JsonParse(text);
        p.skipWs();
        Object v = p.value();
        return v;
    }

    /** 便捷取子对象 */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> arr(Object o) {
        return o instanceof List ? (List<Object>) o : null;
    }

    public static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    /** 按路径取值，例如 path(obj, "response", "url") */
    public static Object path(Object root, String... keys) {
        Object cur = root;
        for (String k : keys) {
            Map<String, Object> m = obj(cur);
            if (m == null) {
                return null;
            }
            cur = m.get(k);
        }
        return cur;
    }

    private Object value() {
        if (pos >= src.length()) {
            return null;
        }
        char c = src.charAt(pos);
        switch (c) {
            case '{':
                return object();
            case '[':
                return array();
            case '"':
                return string();
            case 't':
                expect("true");
                return Boolean.TRUE;
            case 'f':
                expect("false");
                return Boolean.FALSE;
            case 'n':
                expect("null");
                return null;
            default:
                return number();
        }
    }

    private Map<String, Object> object() {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        pos++; // {
        skipWs();
        if (pos < src.length() && src.charAt(pos) == '}') {
            pos++;
            return map;
        }
        while (pos < src.length()) {
            skipWs();
            if (src.charAt(pos) != '"') {
                break;
            }
            String key = string();
            skipWs();
            if (pos < src.length() && src.charAt(pos) == ':') {
                pos++;
            }
            skipWs();
            map.put(key, value());
            skipWs();
            if (pos < src.length() && src.charAt(pos) == ',') {
                pos++;
                continue;
            }
            if (pos < src.length() && src.charAt(pos) == '}') {
                pos++;
            }
            break;
        }
        return map;
    }

    private List<Object> array() {
        List<Object> list = new ArrayList<Object>();
        pos++; // [
        skipWs();
        if (pos < src.length() && src.charAt(pos) == ']') {
            pos++;
            return list;
        }
        while (pos < src.length()) {
            skipWs();
            list.add(value());
            skipWs();
            if (pos < src.length() && src.charAt(pos) == ',') {
                pos++;
                continue;
            }
            if (pos < src.length() && src.charAt(pos) == ']') {
                pos++;
            }
            break;
        }
        return list;
    }

    private String string() {
        StringBuilder sb = new StringBuilder();
        pos++; // opening quote
        while (pos < src.length()) {
            char c = src.charAt(pos++);
            if (c == '"') {
                break;
            }
            if (c == '\\') {
                if (pos >= src.length()) {
                    break;
                }
                char e = src.charAt(pos++);
                switch (e) {
                    case 'n':
                        sb.append('\n');
                        break;
                    case 'r':
                        sb.append('\r');
                        break;
                    case 't':
                        sb.append('\t');
                        break;
                    case 'b':
                        sb.append('\b');
                        break;
                    case 'f':
                        sb.append('\f');
                        break;
                    case 'u':
                        if (pos + 4 <= src.length()) {
                            try {
                                sb.append((char) Integer.parseInt(src.substring(pos, pos + 4), 16));
                            } catch (RuntimeException ignored) {
                                // 忽略坏转义
                            }
                            pos += 4;
                        }
                        break;
                    default:
                        sb.append(e);
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private Double number() {
        int start = pos;
        while (pos < src.length()) {
            char c = src.charAt(pos);
            if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') {
                pos++;
            } else {
                break;
            }
        }
        if (start == pos) {
            pos++;
            return Double.valueOf(0);
        }
        try {
            return Double.valueOf(src.substring(start, pos));
        } catch (NumberFormatException e) {
            return Double.valueOf(0);
        }
    }

    private void expect(String word) {
        pos += word.length();
    }

    private void skipWs() {
        while (pos < src.length()) {
            char c = src.charAt(pos);
            if (c == ' ' || c == '\n' || c == '\r' || c == '\t') {
                pos++;
            } else {
                break;
            }
        }
    }
}
