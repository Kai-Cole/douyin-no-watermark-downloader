package douyin;

import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** 媒体转发：绕开抖音 CDN 的防盗链（必须带 Referer / UA），支持 Range 拖动播放 */
public final class Media {

    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

    private Media() {
    }

    public static void stream(HttpExchange ex, String target, boolean attachment, String filename) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(target);
            conn = (HttpURLConnection) u.openConnection();
            conn.setRequestProperty("User-Agent", UA);
            conn.setRequestProperty("Referer", "https://www.douyin.com/");
            String range = ex.getRequestHeaders().getFirst("Range");
            if (range != null && !range.isEmpty()) {
                conn.setRequestProperty("Range", range);
            }
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);

            int code = conn.getResponseCode();
            if (code >= 400) {
                sendJson(ex, 502, "{\"code\":1,\"msg\":\"源地址不可用，" + Json.quote("HTTP " + code) + "\"}");
                return;
            }

            String ctype = conn.getContentType();
            if (ctype == null || ctype.isEmpty()) {
                ctype = "application/octet-stream";
            }
            long len = conn.getContentLengthLong();

            ex.getResponseHeaders().set("Content-Type", ctype);
            ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
            ex.getResponseHeaders().set("Accept-Ranges", "bytes");
            if (conn.getHeaderField("Content-Range") != null) {
                ex.getResponseHeaders().set("Content-Range", conn.getHeaderField("Content-Range"));
            }
            if (attachment) {
                ex.getResponseHeaders().set("Content-Disposition", disposition(filename));
            }
            if (len > 0) {
                ex.sendResponseHeaders(code, len);
            } else {
                ex.sendResponseHeaders(code, 0);   // 0 = 分块传输
            }

            InputStream in = conn.getInputStream();
            OutputStream out = ex.getResponseBody();
            byte[] buf = new byte[262144];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                out.flush();
            }
            in.close();
            out.flush();
            ex.close();
        } catch (IOException e) {
            try {
                sendJson(ex, 502, "{\"code\":1,\"msg\":\"转发失败：" + Json.quote(e.getMessage()) + "\"}");
            } catch (IOException ignored) {
                // 客户端可能已经断开
            }
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    /** 中文文件名：ASCII 兜底 + RFC 5987 的 filename* 双写 */
    private static String disposition(String filename) {
        String name = filename == null || filename.trim().isEmpty() ? "douyin.mp4" : filename.trim();
        String ascii = name.replaceAll("[^\\x20-\\x7e]", "_").replace("\"", "_");
        if (ascii.trim().isEmpty() || ascii.replace("_", "").trim().isEmpty()) {
            ascii = "douyin_media";
        }
        String encoded;
        try {
            encoded = URLEncoder.encode(name, "UTF-8").replace("+", "%20");
        } catch (IOException e) {
            encoded = ascii;
        }
        return "attachment; filename=\"" + ascii + "\"; filename*=UTF-8''" + encoded;
    }

    public static void sendJson(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes("UTF-8");
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        ex.sendResponseHeaders(code, bytes.length);
        OutputStream out = ex.getResponseBody();
        out.write(bytes);
        out.close();
        ex.close();
    }
}
