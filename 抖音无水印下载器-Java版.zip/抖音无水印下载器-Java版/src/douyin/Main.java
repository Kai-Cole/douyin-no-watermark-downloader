package douyin;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.awt.Desktop;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * 抖音无水印下载器（Java 版）
 *
 * 纯 JDK 8 实现，零第三方依赖：
 *   - com.sun.net.httpserver 当 Web 服务器
 *   - 真实 Edge/Chrome 负责拿数据，扩展 hook.js 负责回传
 *   - 本类负责路由、参数解析、文件名、下载转发
 */
public final class Main {

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static volatile Map<String, Object> lastData = null;
    private static File webIndex;

    public static void main(String[] args) throws Exception {
        Engine.init();
        String home = System.getProperty("nowm.home", System.getProperty("user.dir", "."));
        webIndex = new File(new File(home, "web"), "index.html");

        int port = 3000;
        String envPort = System.getenv("PORT");
        if (envPort != null && !envPort.trim().isEmpty()) {
            try {
                port = Integer.parseInt(envPort.trim());
            } catch (NumberFormatException ignored) {
                port = 3000;
            }
        }

        printBanner(port);

        final HttpServer server;
        try {
            server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
        } catch (IOException e) {
            System.out.println("  端口 " + port + " 已被占用 —— 程序可能已经在运行了。");
            System.out.println("  已为你打开 http://127.0.0.1:" + port);
            openBrowser("http://127.0.0.1:" + port);
            Thread.sleep(4000L);
            return;
        }
        server.setExecutor(Executors.newCachedThreadPool());
        server.createContext("/", new Router());
        server.start();
        openBrowser("http://127.0.0.1:" + port);
        System.out.println("  服务已就绪，按 Ctrl+C 停止。");
    }

    private static void printBanner(int port) {
        String ip = lanIp();
        System.out.println("");
        System.out.println("  ===============================================");
        System.out.println("   抖音无水印下载器（Java 版）已启动");
        System.out.println("   本机打开：   http://127.0.0.1:" + port);
        System.out.println("   其他设备：   http://" + ip + ":" + port + "  （同一 WiFi / 局域网）");
        System.out.println("   浏览器内核： " + (Engine.browserFound() ? Engine.browserName() : "未找到（请装 Edge/Chrome）"));
        System.out.println("   登录状态：   " + (Engine.loggedIn() ? "看起来已登录" : "未登录（页面里点“登录抖音”）"));
        System.out.println("   关闭这个窗口即可停止程序");
        System.out.println("  ===============================================");
        System.out.println("");
    }

    /** 取本机真正在用的局域网 IPv4（先按路由出口判断，再退回遍历网卡并排除虚拟网卡） */
    private static String lanIp() {
        try {
            java.net.Socket probe = new java.net.Socket();
            probe.connect(new java.net.InetSocketAddress("223.5.5.5", 80), 1500);
            java.net.InetAddress local = probe.getLocalAddress();
            probe.close();
            if (local != null && local.getAddress().length == 4) {
                return local.getHostAddress();
            }
        } catch (Exception ignored) {
            // 没网或探测失败，走下面的遍历
        }
        try {
            java.util.Enumeration<java.net.NetworkInterface> nis =
                    java.net.NetworkInterface.getNetworkInterfaces();
            while (nis.hasMoreElements()) {
                java.net.NetworkInterface ni = nis.nextElement();
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                String name = ni.getName() == null ? "" : ni.getName().toLowerCase();
                if (name.startsWith("vmware") || name.startsWith("vethernet")
                        || name.startsWith("virtual") || name.startsWith("loopback")) {
                    continue;
                }
                java.util.Enumeration<java.net.InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    java.net.InetAddress a = addrs.nextElement();
                    if (a.getAddress().length != 4 || !a.isSiteLocalAddress()) {
                        continue;
                    }
                    String ip = a.getHostAddress();
                    if (ip.startsWith("192.168.189.") || ip.startsWith("192.168.65.")) {
                        continue;   // VMware NAT / host-only 网段
                    }
                    return ip;
                }
            }
        } catch (Exception ignored) {
            // 忽略
        }
        return "127.0.0.1";
    }

    private static void openBrowser(String url) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(new URI(url));
                return;
            }
        } catch (Exception ignored) {
            // 继续用下面的兜底
        }
        try {
            Runtime.getRuntime().exec(new String[]{"rundll32", "url.dll,FileProtocolHandler", url});
        } catch (Exception ignored) {
            // 忽略
        }
    }

    // ------------------------------------------------------------------ 路由
 private static final class Router implements HttpHandler {

        @Override
        public void handle(HttpExchange ex) throws IOException {
            String path = ex.getRequestURI().getPath();
            String method = ex.getRequestMethod();
            try {
                if (path.equals("/") || path.equals("/index.html")) {
                    serveIndex(ex);
                    return;
                }
                if (path.equals("/api/health")) {
                    handleHealth(ex);
                    return;
                }
                if (path.equals("/api/parse") && method.equals("POST")) {
                    handleParse(ex);
                    return;
                }
                if (path.equals("/api/checklogin")) {
                    boolean ok = Engine.checkLoginNow();
                    Media.sendJson(ex, 200, "{\"ok\":" + ok + "}");
                    return;
                }
                if (path.equals("/api/login") && method.equals("POST")) {
                    boolean ok = Engine.login();
                    Media.sendJson(ex, 200, "{\"ok\":" + ok + "}");
                    return;
                }
                if (path.equals("/api/proxy")) {
                    String url = query(ex).get("url");
                    if (url == null || url.isEmpty()) {
                        Media.sendJson(ex, 400, "{\"code\":1,\"msg\":\"缺少 url\"}");
                        return;
                    }
                    Media.stream(ex, url, false, null);
                    return;
                }
                if (path.equals("/api/download")) {
                    handleDownload(ex);
                    return;
                }
                Media.sendJson(ex, 404, "{\"code\":1,\"msg\":\"not found\"}");
            } catch (Exception e) {
                // 头已经发出去的话这里会抛异常，忽略即可
                try {
                    Media.sendJson(ex, 500, "{\"code\":1,\"msg\":" + Json.quote(String.valueOf(e.getMessage())) + "}");
                } catch (IOException ignored) {
                    // 忽略
                }
            }
        }

        private void serveIndex(HttpExchange ex) throws IOException {
            if (webIndex == null || !webIndex.isFile()) {
                Media.sendJson(ex, 500,
                        "{\"code\":1,\"msg\":" + Json.quote("缺少 web/index.html：" + webIndex) + "}");
                return;
            }
            byte[] body = Files.readAllBytes(webIndex.toPath());
            ex.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            ex.getResponseHeaders().set("Cache-Control", "no-store");
            ex.sendResponseHeaders(200, body.length);
            OutputStream out = ex.getResponseBody();
            out.write(body);
            out.close();
            ex.close();
        }

        private void handleHealth(HttpExchange ex) throws IOException {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("code", 0);
            m.put("login", Engine.loggedIn());
            m.put("engine", Engine.browserFound() ? Engine.browserName() : "none");
            Media.sendJson(ex, 200, Json.dump(m));
        }

        private void handleParse(HttpExchange ex) throws IOException {
            String body = readBody(ex);
            String text = Json.field(body, "text");
            if (text == null || text.trim().isEmpty()) {
                Media.sendJson(ex, 400, "{\"ok\":false,\"code\":\"FAIL\",\"msg\":\"先粘贴链接\"}");
                return;
            }
            System.out.println("  [解析] " + text.replace('\n', ' '));
            Map<String, Object> result = Engine.parse(text);
            @SuppressWarnings("unchecked")
            Map<String, Object> data = (Map<String, Object>) result.get("data");
            if (data != null) {
                lastData = data;
                System.out.println("  [成功] " + data.get("author") + " / " + data.get("title"));
            } else {
                System.out.println("  [失败] " + result.get("msg"));
            }
            Media.sendJson(ex, 200, Json.dump(result));
        }

        private void handleDownload(HttpExchange ex) throws IOException {
            Map<String, String> q = query(ex);
            String url = q.get("url");
            String idx = q.get("idx");
            if (url == null || url.isEmpty()) {
                Media.sendJson(ex, 400, "{\"code\":1,\"msg\":\"缺少 url\"}");
                return;
            }
            boolean isImage = "image".equals(lastData == null ? "" : String.valueOf(lastData.get("type")));
            String name = safeName(lastData == null ? null : (String) lastData.get("title"));
            if (isImage) {
                name = name + (idx == null ? "" : "_" + idx) + ".jpg";
            } else {
                name = name + ".mp4";
            }
            Media.stream(ex, url, true, name);
        }

        private String safeName(String title) {
            String s = title == null || title.trim().isEmpty() ? "douyin_video" : title.trim();
            s = s.replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
            while (s.startsWith("_")) {
                s = s.substring(1);
            }
            if (s.length() > 60) {
                s = s.substring(0, 60);
            }
            return s.isEmpty() ? "douyin_video" : s;
        }

        private String readBody(HttpExchange ex) throws IOException {
            InputStream in = ex.getRequestBody();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            in.close();
            return new String(bos.toByteArray(), UTF8);
        }

        private Map<String, String> query(HttpExchange ex) {
            Map<String, String> map = new HashMap<String, String>();
            String q = ex.getRequestURI().getRawQuery();
            if (q == null || q.isEmpty()) {
                return map;
            }
            for (String pair : q.split("&")) {
                int eq = pair.indexOf('=');
                if (eq < 0) {
                    continue;
                }
                String k = Engine.urlDecode(pair.substring(0, eq));
                String v = Engine.urlDecode(pair.substring(eq + 1));
                map.put(k, v);
            }
            return map;
        }

        /** application/x-www-form-urlencoded 或 text/plain 两种都能解析 */
        private Map<String, String> parseForm(String body) {
            Map<String, String> map = new HashMap<String, String>();
            if (body == null || body.isEmpty()) {
                return map;
            }
            for (String pair : body.split("&")) {
                int eq = pair.indexOf('=');
                if (eq < 0) {
                    continue;
                }
                String k = Engine.urlDecode(pair.substring(0, eq));
                String v = Engine.urlDecode(pair.substring(eq + 1));
                map.put(k, v);
            }
            return map;
        }
    }

    /** 供未来扩展：取最近一次解析结果 */
    @SuppressWarnings("unused")
    public static Map<String, Object> lastData() {
        return lastData;
    }

    @SuppressWarnings("unused")
    private static List<String> unused() {
        return null;
    }
}
