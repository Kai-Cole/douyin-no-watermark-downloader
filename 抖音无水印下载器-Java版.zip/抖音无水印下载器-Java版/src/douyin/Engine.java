package douyin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 解析引擎（Java 版）：走 Chrome DevTools Protocol。
 *
 * 为什么不能纯 HTTP 解析：
 *   2026 年抖音把接口封干净了 —— 老 iteminfo 接口返回空 body，分享页
 *   _ROUTER_DATA 里没有 videoInfoRes，直连 aweme/detail 是 403，裸请求视频页
 *   拿到的是 JS 反爬空壳，未登录还会弹滑块。所以只能让真实浏览器带着登录态去取。
 *
 * 实现路径：
 *   1. 用 --remote-debugging-port 启动 Edge（扩展命令行的 --load-extension 已被
 *      新版浏览器禁掉，所以改用调试协议，这个不会被拦）
 *   2. HTTP 调 /json/new 开标签页
 *   3. WebSocket 连上去，Network.enable 后监听 Network.responseReceived，
 *      发现 aweme/detail 就用 Network.getResponseBody 拿原始 JSON
 *   4. 从中取出 play_addr.url_list（web 播放器流本身不带水印层）
 */
public final class Engine {

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final int DEBUG_PORT = 9222;

    private static File homeDir;
    private static File profileDir;
    private static String browserPath;
    private static String browserName = "edge";
    private static boolean loggedInCache = true;
    private static long loggedInTs = 0L;

    private static final Object BROWSER_LOCK = new Object();

    private Engine() {
    }

    // ------------------------------------------------------------------ 初始化
    public static synchronized void init() {
        homeDir = resolveHome();
        profileDir = resolveProfileDir();
        if (!profileDir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            profileDir.mkdirs();
            copyInitialProfile();
        }
        browserPath = findBrowser();
        if (browserPath != null) {
            String n = new File(browserPath).getName().toLowerCase();
            browserName = n.contains("chrome") ? "chrome" : "edge";
        }
    }

    private static File resolveHome() {
        String prop = System.getProperty("nowm.home");
        if (prop != null && !prop.trim().isEmpty()) {
            File f = new File(prop);
            if (f.isDirectory()) {
                return f;
            }
        }
        return new File(System.getProperty("user.dir", "."));
    }

    /** 独立的 profile，避免和 Python 版抢同一个目录导致端口/窗口冲突 */
    private static File resolveProfileDir() {
        String env = System.getenv("DOUYIN_PROFILE_JAVA");
        if (env != null && !env.trim().isEmpty()) {
            return new File(env.trim());
        }
        if (System.getenv("DOUYIN_PROFILE") != null && !System.getenv("DOUYIN_PROFILE").trim().isEmpty()) {
            return new File(System.getenv("DOUYIN_PROFILE").trim());
        }
        String la = System.getenv("LOCALAPPDATA");
        if (la != null && !la.trim().isEmpty()) {
            return new File(new File(la, "DouyinNoWM-java"), "browser-profile");
        }
        return new File(homeDir, "browser-profile");
    }

    /**
     * 首次运行时，从 Python 版已经登录过的 profile 复制过来 ——
     * 同一台电脑、同一个 Windows 用户，Chromium 的 cookie 加密密钥是同一把，复制即可复用登录态。
     */
    private static void copyInitialProfile() {
        String la = System.getenv("LOCALAPPDATA");
        if (la == null || la.trim().isEmpty()) {
            return;
        }
        final File src = new File(new File(la, "DouyinNoWM"), "browser-profile");
        if (!src.isDirectory()) {
            return;
        }
        try {
            Files.walkFileTree(src.toPath(), new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    File target = new File(profileDir, src.toPath().relativize(dir).toString());
                    if (!target.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        target.mkdirs();
                    }
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    try {
                        File target = new File(profileDir, src.toPath().relativize(file).toString());
                        if (!target.exists()) {
                            Files.copy(file, target.toPath());
                        }
                    } catch (IOException ignored) {
                        // 单个文件失败不影响整体
                    }
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) {
                    return FileVisitResult.CONTINUE;
                }
            });
            System.out.println("  已从 Python 版复制抖音登录态到 " + profileDir.getAbsolutePath());
        } catch (IOException e) {
            System.out.println("  复制登录态失败（可以稍后在页面里点“登录抖音”）：" + e.getMessage());
        }
    }

    private static String findBrowser() {
        String env = System.getenv("CHROME_PATH");
        if (env != null && new File(env).isFile()) {
            return env;
        }
        String la = System.getenv("LOCALAPPDATA");
        List<String> candidates = new ArrayList<String>();
        candidates.add("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
        candidates.add("C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
        if (la != null) {
            candidates.add(la + "\\Google\\Chrome\\Application\\chrome.exe");
        }
        candidates.add("C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe");
        candidates.add("C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe");
        for (String c : candidates) {
            if (new File(c).isFile()) {
                return c;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ 对外状态
    public static String browserName() {
        return browserName;
    }

    public static boolean browserFound() {
        return browserPath != null;
    }

    public static boolean loggedIn() {
        return loggedInCache;
    }

    // ------------------------------------------------------------------ 浏览器
    /** 确保调试端口可用；必要时启动 Edge */
    private static String ensureBrowserEndpoint() throws IOException {
        String ver = http("GET", "http://127.0.0.1:" + DEBUG_PORT + "/json/version", 2500);
        if (ver != null) {
            return ver;
        }
        if (browserPath == null) {
            throw new IOException("没有找到 Chrome / Edge，请装其一后重试");
        }
        launchEdge(null);
        long t0 = System.currentTimeMillis();
        while (System.currentTimeMillis() - t0 < 25000L) {
            try {
                Thread.sleep(700L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
            ver = http("GET", "http://127.0.0.1:" + DEBUG_PORT + "/json/version", 2500);
            if (ver != null) {
                return ver;
            }
        }
        throw new IOException("浏览器调试端口没起来，可能有别的 Edge 窗口占着这个授权目录"
                + "（请把本工具的 Edge 窗口全部关掉后重试）");
    }

    private static void launchEdge(String url) throws IOException {
        List<String> cmd = new ArrayList<String>();
        cmd.add(browserPath);
        cmd.add("--user-data-dir=" + profileDir.getAbsolutePath());
        cmd.add("--remote-debugging-port=" + DEBUG_PORT);
        cmd.add("--no-first-run");
        cmd.add("--no-default-browser-check");
        cmd.add("--disable-blink-features=AutomationControlled");
        cmd.add("--disable-features=msEdgeSidebarV2");
        cmd.add("--lang=zh-CN");
        cmd.add(url == null || url.isEmpty() ? "about:blank" : url);

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        File logDir = new File(homeDir, "logs");
        if (!logDir.isDirectory()) {
            //noinspection ResultOfMethodCallIgnored
            logDir.mkdirs();
        }
        pb.redirectOutput(ProcessBuilder.Redirect.appendTo(new File(logDir, "browser.log")));
        pb.start();
        System.out.println("  已启动浏览器：" + browserPath);
    }

    /** 打开一个新标签页，返回 {pageId, wsUrl} */
    private static Map<String, String> openPage(String url) throws IOException {
        ensureBrowserEndpoint();
        String target = "http://127.0.0.1:" + DEBUG_PORT + "/json/new?" + urlEncode(url);
        String body = http("PUT", target, 15000);
        if (body == null) {
            throw new IOException("打不开新标签页（浏览器没响应）");
        }
        Object parsed = JsonParse.parse(body);
        Map<String, Object> m = JsonParse.obj(parsed);
        if (m == null || m.get("webSocketDebuggerUrl") == null) {
            throw new IOException("标签页没返回调试地址: " + body);
        }
        Map<String, String> out = new LinkedHashMap<String, String>();
        out.put("id", JsonParse.str(m.get("id")));
        out.put("ws", JsonParse.str(m.get("webSocketDebuggerUrl")));
        return out;
    }

    private static void closePage(String pageId) {
        if (pageId == null || pageId.isEmpty()) {
            return;
        }
        http("GET", "http://127.0.0.1:" + DEBUG_PORT + "/json/close/" + pageId, 3000);
    }

    // ------------------------------------------------------------------ 解析
    public static String extractLink(String text) {
        if (text == null) {
            return null;
        }
        String[] parts = text.split("\\s+");
        for (String p : parts) {
            if (p.startsWith("http://") || p.startsWith("https://")) {
                String clean = stripTail(p);
                if (clean.contains("douyin.com")) {
                    return clean;
                }
            }
        }
        for (String p : parts) {
            if (p.startsWith("http://") || p.startsWith("https://")) {
                return stripTail(p);
            }
        }
        return null;
    }

    private static String stripTail(String u) {
        int cut = u.length();
        String stops = "\"'<>（）【】(),;，。、";
        for (int i = 0; i < stops.length(); i++) {
            int idx = u.indexOf(stops.charAt(i));
            if (idx > 0 && idx < cut) {
                cut = idx;
            }
        }
        return u.substring(0, cut);
    }

    public static Map<String, Object> parse(String text) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        String link = extractLink(text);
        if (link == null) {
            out.put("ok", Boolean.FALSE);
            out.put("code", "FAIL");
            out.put("msg", "没找到链接，请粘贴完整分享文案");
            return out;
        }
        if (browserPath == null) {
            out.put("ok", Boolean.FALSE);
            out.put("code", "FAIL");
            out.put("msg", "没找到 Chrome / Edge 浏览器，无法解析");
            return out;
        }

        synchronized (BROWSER_LOCK) {
            String pageId = null;
            Ws ws = null;
            try {
                Map<String, String> page = openPage(link);
                pageId = page.get("id");
                ws = Ws.connect(page.get("ws"), 8000);

                String enable = "{\"id\":1,\"method\":\"Network.enable\",\"params\":{}}";
                ws.sendText(enable);
                boolean debug = "1".equals(System.getenv("NOWM_DEBUG"));
                if (debug) {
                    System.out.println("  [debug] CDP 已连接，开始监听 aweme/detail");
                }

                int rpcId = 2;
                int pendingBodyId = -1;
                String captured = null;
                int msgCount = 0;
                int respCount = 0;
                long t0 = System.currentTimeMillis();

                while (System.currentTimeMillis() - t0 < 45000L) {
                    String msg = ws.readText(1200);
                    if (msg == null) {
                        continue;
                    }
                    msgCount++;
                    Map<String, Object> m = JsonParse.obj(JsonParse.parse(msg));
                    if (m == null) {
                        continue;
                    }
                    String method = JsonParse.str(m.get("method"));

                    if ("Network.responseReceived".equals(method)) {
                        Map<String, Object> params = JsonParse.obj(m.get("params"));
                        if (params == null) {
                            continue;
                        }
                        Map<String, Object> response = JsonParse.obj(params.get("response"));
                        if (response == null) {
                            continue;
                        }
                        String u = JsonParse.str(response.get("url"));
                        respCount++;
                        if (debug && respCount <= 40) {
                            System.out.println("  [debug] resp " + JsonParse.str(response.get("status"))
                                    + " " + JsonParse.str(response.get("mimeType")) + " " + u);
                        }
                        if (u.contains("aweme/detail")) {
                            String requestId = JsonParse.str(params.get("requestId"));
                            String cmd = "{\"id\":" + rpcId + ",\"method\":\"Network.getResponseBody\","
                                    + "\"params\":{\"requestId\":" + Json.quote(requestId) + "}}";
                            pendingBodyId = rpcId;
                            rpcId++;
                            ws.sendText(cmd);
                            if (debug) {
                                System.out.println("  [debug] 命中 aweme/detail → 取响应体 " + requestId);
                            }
                        }
                    } else if (pendingBodyId > 0 && m.get("id") != null) {
                        Object idObj = m.get("id");
                        double idVal = idObj instanceof Number ? ((Number) idObj).doubleValue() : -1;
                        if (((int) idVal) == pendingBodyId) {
                            Map<String, Object> result = JsonParse.obj(m.get("result"));
                            if (result != null) {
                                String body = JsonParse.str(result.get("body"));
                                if (Boolean.TRUE.equals(result.get("base64Encoded"))) {
                                    body = new String(
                                            javax.xml.bind.DatatypeConverter.parseBase64Binary(body), UTF8);
                                }
                                if (body != null && body.length() > 100) {
                                    captured = body;
                                    break;
                                }
                            }
                            pendingBodyId = -1;
                        }
                    }
                }
                if (debug) {
                    System.out.println("  [debug] 共收到 ws 消息 " + msgCount + " 条，网络响应 " + respCount + " 条");
                }

                if (debug && captured == null) {
                    // 抓不到时看看页面究竟停在哪：URL + 标题 + 正文开头
                    ws.sendText("{\"id\":900,\"method\":\"Runtime.evaluate\",\"params\":{\"expression\":"
                            + Json.quote("location.href + ' | ' + document.title + ' | ' + "
                            + "(document.body ? document.body.innerText.slice(0,150) : '')") + "}}");
                    long dt = System.currentTimeMillis();
                    while (System.currentTimeMillis() - dt < 4000L) {
                        String dm = ws.readText(800);
                        if (dm == null) {
                            continue;
                        }
                        Map<String, Object> dmObj = JsonParse.obj(JsonParse.parse(dm));
                        if (dmObj == null) {
                            continue;
                        }
                        Object idObj = dmObj.get("id");
                        if (idObj instanceof Number && ((Number) idObj).intValue() == 900) {
                            String v = JsonParse.str(JsonParse.path(dmObj, "result", "result", "value"));
                            System.out.println("  [debug] 页面现状: " + v);
                            break;
                        }
                    }
                }

                if (captured != null) {
                    Map<String, Object> data = pickFromDetail(captured);
                    if (data != null) {
                        out.put("ok", Boolean.TRUE);
                        out.put("data", data);
                        return out;
                    }
                }
            } catch (IOException e) {
                out.put("ok", Boolean.FALSE);
                out.put("code", "FAIL");
                out.put("msg", "调用浏览器失败：" + e.getMessage());
                return out;
            } finally {
                if (ws != null) {
                    ws.close();
                }
            }

            boolean alive = checkLoginQuiet();
            loggedInCache = alive;
            loggedInTs = System.currentTimeMillis();
            out.put("ok", Boolean.FALSE);
            if (!alive) {
                out.put("code", "NEED_LOGIN");
                out.put("msg", "抖音要求登录/验证。点页面上的「登录抖音」扫码一次再解析");
            } else {
                out.put("code", "FAIL");
                out.put("msg", "没抓到作品数据，作品可能已删除、私密，或需要重新登录抖音");
            }
            return out;
        }
    }

    /** 从 aweme_detail 原始 JSON 里抽无水印地址 */
    private static Map<String, Object> pickFromDetail(String jsonText) {
        Object root = JsonParse.parse(jsonText);
        Map<String, Object> j = JsonParse.obj(root);
        if (j == null) {
            return null;
        }
        Map<String, Object> d = JsonParse.obj(j.get("aweme_detail"));
        if (d == null) {
            d = JsonParse.obj(j.get("aweme"));
        }
        if (d == null) {
            d = j;
        }
        Map<String, Object> video = JsonParse.obj(d.get("video"));
        if (video == null && JsonParse.arr(d.get("images")) == null) {
            return null;
        }
        Map<String, Object> play = video == null ? null : JsonParse.obj(video.get("play_addr"));

        List<String> urls = new ArrayList<String>();
        List<Object> urlList = play == null ? null : JsonParse.arr(play.get("url_list"));
        if (urlList != null) {
            for (Object o : urlList) {
                String u = JsonParse.str(o)
                        .replace("/playwm/", "/play/")
                        .replace("playwm", "play");
                if (!urls.contains(u) && !u.isEmpty()) {
                    urls.add(u);
                }
            }
        }
        String uri = play == null ? "" : JsonParse.str(play.get("uri"));
        if (!uri.isEmpty()) {
            urls.add("https://aweme.snssdk.com/aweme/v1/play/?video_id=" + uri + "&ratio=1080p&line=0");
        }

        List<String> images = new ArrayList<String>();
        List<Object> imgs = JsonParse.arr(d.get("images"));
        if (imgs != null) {
            for (Object o : imgs) {
                Map<String, Object> img = JsonParse.obj(o);
                if (img == null) {
                    continue;
                }
                List<Object> lst = JsonParse.arr(img.get("url_list"));
                if (lst != null && !lst.isEmpty()) {
                    String pick = lst.size() > 1 ? JsonParse.str(lst.get(lst.size() - 1)) : JsonParse.str(lst.get(0));
                    if (!pick.isEmpty()) {
                        images.add(pick);
                    }
                }
            }
        }

        String author = "";
        String avatar = "";
        Map<String, Object> a = JsonParse.obj(d.get("author"));
        if (a != null) {
            author = JsonParse.str(a.get("nickname"));
            List<Object> av = JsonParse.arr(JsonParse.path(a, "avatar_thumb", "url_list"));
            if (av != null && !av.isEmpty()) {
                avatar = JsonParse.str(av.get(0));
            }
        }

        String cover = "";
        if (video != null) {
            List<Object> c1 = JsonParse.arr(JsonParse.path(video, "cover", "url_list"));
            if (c1 != null && !c1.isEmpty()) {
                cover = JsonParse.str(c1.get(0));
            } else {
                List<Object> c2 = JsonParse.arr(JsonParse.path(video, "origin_cover", "url_list"));
                if (c2 != null && !c2.isEmpty()) {
                    cover = JsonParse.str(c2.get(0));
                }
            }
        }

        if (urls.isEmpty() && images.isEmpty()) {
            return null;
        }

        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("aweme_id", JsonParse.str(d.get("aweme_id")));
        data.put("type", images.isEmpty() ? "video" : "image");
        data.put("title", JsonParse.str(d.get("desc")));
        data.put("author", author);
        data.put("avatar", avatar);
        data.put("cover", cover);
        data.put("video_url", urls.isEmpty() ? "" : urls.get(0));
        data.put("video_urls", urls);
        data.put("images", images);
        return data;
    }

    // ------------------------------------------------------------------ 登录
    /** 弹出浏览器让用户扫码，检测到登录就返回 true（最长 300 秒） */
    public static boolean login() {
        if (browserPath == null) {
            return false;
        }
        synchronized (BROWSER_LOCK) {
            Map<String, String> page;
            try {
                page = openPage("https://www.douyin.com/");
            } catch (IOException e) {
                System.out.println("  打开登录页失败：" + e.getMessage());
                return false;
            }
            Ws ws = null;
            try {
                ws = Ws.connect(page.get("ws"), 8000);
            } catch (IOException ignored) {
                // 没有 ws 也能靠 cookies 轮询
            }
            long t0 = System.currentTimeMillis();
            while (System.currentTimeMillis() - t0 < 300000L) {
                try {
                    Thread.sleep(2000L);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
                boolean ok = cookiesHaveSession(ws);
                if (ok) {
                    loggedInCache = true;
                    loggedInTs = System.currentTimeMillis();
                    if (ws != null) {
                        ws.close();
                    }
                    return true;
                }
            }
            if (ws != null) {
                ws.close();
            }
            loggedInCache = false;
            loggedInTs = System.currentTimeMillis();
            return false;
        }
    }

    /** 不打扰用户的一次静默登录检查（浏览器没开就返回上次缓存） */
    private static boolean checkLoginQuiet() {
        if (!debugPortAlive()) {
            return loggedInCache;
        }
        Map<String, String> page = null;
        Ws ws = null;
        try {
            page = openPage("about:blank");
            ws = Ws.connect(page.get("ws"), 5000);
            boolean ok = cookiesHaveSession(ws);
            return ok;
        } catch (IOException e) {
            return loggedInCache;
        } finally {
            if (ws != null) {
                ws.close();
            }
            if (page != null) {
                closePage(page.get("id"));
            }
        }
    }

    public static boolean checkLoginNow() {
        synchronized (BROWSER_LOCK) {
            boolean ok = checkLoginQuiet();
            loggedInCache = ok;
            loggedInTs = System.currentTimeMillis();
            return ok;
        }
    }

    private static boolean debugPortAlive() {
        return http("GET", "http://127.0.0.1:" + DEBUG_PORT + "/json/version", 2000) != null;
    }

    /** 用 CDP 的 Network.getAllCookies 判断有没有登录：只认 sessionid 等，匿名访客的 csrf 不算 */
    private static boolean cookiesHaveSession(Ws ws) {
        if (ws == null) {
            return loggedInCache;
        }
        try {
            String cmd = "{\"id\":99,\"method\":\"Network.getAllCookies\"}";
            ws.sendText(cmd);
            long t0 = System.currentTimeMillis();
            while (System.currentTimeMillis() - t0 < 6000L) {
                String msg = ws.readText(1000);
                if (msg == null) {
                    continue;
                }
                Map<String, Object> m = JsonParse.obj(JsonParse.parse(msg));
                if (m == null) {
                    continue;
                }
                Object idObj = m.get("id");
                if (!(idObj instanceof Number) || ((Number) idObj).intValue() != 99) {
                    continue;
                }
                Map<String, Object> result = JsonParse.obj(m.get("result"));
                List<Object> cookies = result == null ? null : JsonParse.arr(result.get("cookies"));
                if (cookies == null) {
                    return loggedInCache;
                }
                for (Object o : cookies) {
                    Map<String, Object> c = JsonParse.obj(o);
                    if (c == null) {
                        continue;
                    }
                    String name = JsonParse.str(c.get("name"));
                    if ("sessionid".equals(name) || "sessionid_ss".equals(name)
                            || "sid_tt".equals(name) || "uid_tt".equals(name)) {
                        return true;
                    }
                }
                return false;
            }
        } catch (IOException ignored) {
            // 忽略
        }
        return loggedInCache;
    }

    // ------------------------------------------------------------------ HTTP 小工具
    private static String http(String method, String url, int timeoutMs) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod(method);
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setInstanceFollowRedirects(true);
            int code = conn.getResponseCode();
            if (code >= 400) {
                return null;
            }
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            in.close();
            return new String(bos.toByteArray(), UTF8);
        } catch (IOException e) {
            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    public static String urlDecode(String s) {
        try {
            return URLDecoder.decode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return s;
        }
    }

    public static String urlEncode(String s) {
        try {
            return URLEncoder.encode(s == null ? "" : s, "UTF-8").replace("+", "%20");
        } catch (UnsupportedEncodingException e) {
            return "";
        }
    }

    @SuppressWarnings("unused")
    private static void writeAll(OutputStream out, byte[] data) throws IOException {
        out.write(data);
        out.flush();
    }
}
