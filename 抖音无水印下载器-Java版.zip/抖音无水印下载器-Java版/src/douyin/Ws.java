package douyin;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.Charset;
import java.util.Random;

/**
 * 极简 WebSocket 客户端（RFC 6455），只为跟 Chrome/Edge 的 CDP 调试端口对话。
 * JDK 8 没有 java.net.http.WebSocket，所以这里手搓一个：
 * 只做 文本帧收发 + ping/pong + 分片拼接，够用。
 */
public final class Ws {

    private static final Charset UTF8 = Charset.forName("UTF-8");

    private final Socket socket;
    private final InputStream in;
    private final OutputStream out;
    private final Random random = new Random();
    private final StringBuilder frag = new StringBuilder();

    private Ws(Socket socket) throws IOException {
        this.socket = socket;
        this.in = new BufferedInputStream(socket.getInputStream());
        this.out = new BufferedOutputStream(socket.getOutputStream());
    }

    /** ws://127.0.0.1:9222/devtools/page/XXXX */
    public static Ws connect(String wsUrl, int timeoutMs) throws IOException {
        if (wsUrl == null || !wsUrl.startsWith("ws://")) {
            throw new IOException("不是 ws 地址: " + wsUrl);
        }
        String rest = wsUrl.substring("ws://".length());
        int slash = rest.indexOf('/');
        String hostPort = slash < 0 ? rest : rest.substring(0, slash);
        String path = slash < 0 ? "/" : rest.substring(slash);

        String host = hostPort;
        int port = 80;
        int colon = hostPort.lastIndexOf(':');
        if (colon > 0) {
            host = hostPort.substring(0, colon);
            try {
                port = Integer.parseInt(hostPort.substring(colon + 1));
            } catch (NumberFormatException ignored) {
                port = 80;
            }
        }

        Socket s = new Socket();
        s.connect(new java.net.InetSocketAddress(host, port), timeoutMs);
        s.setSoTimeout(timeoutMs);
        Ws ws = new Ws(s);

        byte[] keyBytes = new byte[16];
        ws.random.nextBytes(keyBytes);
        String key = javax.xml.bind.DatatypeConverter.printBase64Binary(keyBytes);
        String req = "GET " + path + " HTTP/1.1\r\n"
                + "Host: " + host + ":" + port + "\r\n"
                + "Upgrade: websocket\r\n"
                + "Connection: Upgrade\r\n"
                + "Sec-WebSocket-Key: " + key + "\r\n"
                + "Sec-WebSocket-Version: 13\r\n"
                + "\r\n";
        ws.out.write(req.getBytes(UTF8));
        ws.out.flush();

        String status = readLine(ws.in);
        if (status == null || !status.contains("101")) {
            s.close();
            throw new IOException("WebSocket 握手失败: " + status);
        }
        // 吃掉响应头
        while (true) {
            String line = readLine(ws.in);
            if (line == null || line.isEmpty()) {
                break;
            }
        }
        return ws;
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') {
                break;
            }
            if (c != '\r') {
                bos.write(c);
            }
        }
        if (c == -1 && bos.size() == 0) {
            return null;
        }
        return new String(bos.toByteArray(), UTF8);
    }

    public void sendText(String text) throws IOException {
        byte[] payload = text.getBytes(UTF8);
        int len = payload.length;

        ByteArrayOutputStream frame = new ByteArrayOutputStream();
        frame.write(0x81);           // FIN + text
        if (len < 126) {
            frame.write(0x80 | len);
        } else if (len < 65536) {
            frame.write(0x80 | 126);
            frame.write((len >> 8) & 0xFF);
            frame.write(len & 0xFF);
        } else {
            frame.write(0x80 | 127);
            for (int i = 7; i >= 0; i--) {
                frame.write((int) ((((long) len) >> (8 * i)) & 0xFF));
            }
        }
        byte[] mask = new byte[4];
        random.nextBytes(mask);
        frame.write(mask, 0, 4);
        for (int i = 0; i < len; i++) {
            frame.write(payload[i] ^ mask[i % 4]);
        }
        out.write(frame.toByteArray());
        out.flush();
    }

    /**
     * 读一条文本消息。超时返回 null；对端关闭也返回 null。
     */
    public String readText(int timeoutMs) throws IOException {
        socket.setSoTimeout(timeoutMs);
        while (true) {
            int b0;
            try {
                b0 = in.read();
            } catch (SocketTimeoutException e) {
                return null;
            }
            if (b0 == -1) {
                return null;
            }
            int b1 = in.read();
            if (b1 == -1) {
                return null;
            }
            boolean fin = (b0 & 0x80) != 0;
            int opcode = b0 & 0x0F;
            boolean masked = (b1 & 0x80) != 0;
            long len = b1 & 0x7F;
            if (len == 126) {
                len = ((long) in.read() << 8) | in.read();
            } else if (len == 127) {
                len = 0;
                for (int i = 0; i < 8; i++) {
                    len = (len << 8) | in.read();
                }
            }
            byte[] mask = new byte[4];
            if (masked) {
                readFully(in, mask, 4);
            }
            byte[] payload = new byte[(int) len];
            readFully(in, payload, (int) len);
            if (masked) {
                for (int i = 0; i < payload.length; i++) {
                    payload[i] ^= mask[i % 4];
                }
            }

            if (opcode == 0x8) {           // close
                return null;
            }
            if (opcode == 0x9) {           // ping → pong
                sendControl(0xA, payload);
                continue;
            }
            if (opcode == 0xA) {           // pong
                continue;
            }
            if (opcode == 0x1 || opcode == 0x0) {
                frag.append(new String(payload, UTF8));
                if (fin) {
                    String msg = frag.toString();
                    frag.setLength(0);
                    return msg;
                }
                continue;
            }
            // 二进制帧（CDP 一般不发）直接跳过
        }
    }

    private void sendControl(int opcode, byte[] payload) throws IOException {
        ByteArrayOutputStream frame = new ByteArrayOutputStream();
        frame.write(0x80 | opcode);
        frame.write(0x80 | payload.length);
        byte[] mask = new byte[4];
        random.nextBytes(mask);
        frame.write(mask, 0, 4);
        for (int i = 0; i < payload.length; i++) {
            frame.write(payload[i] ^ mask[i % 4]);
        }
        out.write(frame.toByteArray());
        out.flush();
    }

    private static void readFully(InputStream in, byte[] buf, int len) throws IOException {
        int got = 0;
        while (got < len) {
            int n = in.read(buf, got, len - got);
            if (n < 0) {
                throw new IOException("WebSocket 连接被关闭");
            }
            got += n;
        }
    }

    public void close() {
        try {
            socket.close();
        } catch (IOException ignored) {
            // 忽略
        }
    }
}
